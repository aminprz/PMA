"use client";
import React from "react";

function MainComponent() {
  const [imageLoaded, setImageLoaded] = useState(false);

  return (
    <div className="min-h-screen bg-[#150e60] flex flex-col md:flex-row">
      <div className="w-full md:w-1/2 h-[50vh] md:h-screen">
        {!imageLoaded && (
          <div className="w-full h-full bg-[#1a1260] animate-pulse"></div>
        )}
        <img
          src="https://imgurl.ir/uploads/a625649_Untitled_design_1.gif"
          alt="Automation process visualization"
          className={`w-full h-full object-cover ${
            imageLoaded ? "block" : "hidden"
          }`}
          onLoad={() => setImageLoaded(true)}
        />
      </div>

      <div className="w-full md:w-1/2 flex flex-col justify-center px-8 md:px-12 py-12 md:py-8">
        <div className="space-y-4 mb-16">
          <h1 className="text-[#cfe6ff] text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-agrandir font-bold">
            Automation begins with a single step.
          </h1>

          <p className="text-[#cfe6ff] text-base sm:text-lg font-agrandir">
            Process Management System
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-3">
          <a
            href="/login"
            className="h-12 rounded-full px-8 sm:px-16 border border-[#93c5fd] text-[#93c5fd] hover:bg-[#93c5fd] hover:bg-opacity-10 transition-all duration-300 w-full sm:w-auto text-center leading-[48px]"
          >
            Start
          </a>
          <a
            href="/register"
            className="h-12 rounded-full px-4 sm:px-5 border border-[#22c55e] text-[#22c55e] hover:bg-[#22c55e] hover:bg-opacity-10 transition-all duration-300 w-full sm:w-[120px] text-sm text-center leading-[48px]"
          >
            Register
          </a>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;